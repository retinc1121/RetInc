package ru.royaludprelay;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * RoyalUDPRelay — строго серверный (environment = server) Fabric-мод.
 *
 * НИКОГДА не добавляйте сюда:
 *  - ClientModInitializer / client entrypoint;
 *  - client-side networking (ClientPlayNetworking и т.п.);
 *  - custom payload packets, отправляемые клиенту;
 *  - обязательный handshake с клиентом.
 *
 * Мод — это просто локальный UDP <-> WSS relay клиент, который работает
 * полностью на стороне сервера. Игровой (ванильный) Minecraft-протокол
 * не модифицируется и не используется.
 */
public final class RoyalUDPRelay implements ModInitializer {

    public static final String MOD_ID = "royaludprelay";
    public static final Logger LOGGER = LoggerFactory.getLogger("RoyalUDPRelay");

    private static RoyalUDPRelay instance;

    private RelayConfig config;
    private UdpForwarder udpForwarder;
    private RelayClient relayClient;

    @Override
    public void onInitialize() {
        instance = this;

        LOGGER.info("[RoyalUDPRelay] Starting RoyalUDPRelay...");

        this.config = RelayConfig.loadOrCreate();

        if (!config.enabled) {
            LOGGER.info("[RoyalUDPRelay] enabled=false в конфиге — мод не будет запущен.");
            return;
        }

        this.udpForwarder = new UdpForwarder(config);
        this.relayClient = new RelayClient(config, udpForwarder);
        this.udpForwarder.setRelayClient(relayClient);

        ServerLifecycleEvents.SERVER_STARTED.register(server -> start());
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> shutdown());

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                RoyalUdpCommand.register(dispatcher));
    }

    private void start() {
        LOGGER.info("[RoyalUDPRelay] Local UDP endpoint: {}:{}", config.localHost, config.localPort);
        udpForwarder.start();

        LOGGER.info("[RoyalUDPRelay] Connecting to relay...");
        relayClient.connect();
    }

    private void shutdown() {
        LOGGER.info("[RoyalUDPRelay] Shutting down...");
        if (relayClient != null) {
            relayClient.shutdown();
        }
        if (udpForwarder != null) {
            udpForwarder.stop();
        }
        LOGGER.info("[RoyalUDPRelay] Stopped.");
    }

    public static RoyalUDPRelay getInstance() {
        return instance;
    }

    public RelayConfig getConfig() {
        return config;
    }

    public RelayClient getRelayClient() {
        return relayClient;
    }

    public UdpForwarder getUdpForwarder() {
        return udpForwarder;
    }
}
