package ru.royaludprelay;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Простой TOML-lite конфиг: {@code key = value} построчно, комментарии через '#'.
 * Специально не подключаем внешнюю TOML-библиотеку — формат из ТЗ достаточно прост.
 */
public final class RelayConfig {

    public boolean enabled = true;

    public String serverUuid = UUID.randomUUID().toString();

    public String relayUrl = "wss://relay.example.com";
    public String authToken = "CHANGE_ME";

    public String localHost = "127.0.0.1";
    public int localPort = 11851;

    public String assignedHost = "";
    public int assignedPort = 0;

    public boolean stickyAddress = true;

    public boolean reconnect = true;
    public long reconnectDelayMs = 2000L;
    public long maxReconnectDelayMs = 30000L;

    public String logLevel = "INFO";

    // Дополнительные защитные лимиты (см. раздел "Безопасность" в ТЗ).
    public int maxUdpPacketSize = 4096;
    public long udpSessionIdleTimeoutMs = 60_000L;

    private transient Path path;

    public static RelayConfig loadOrCreate() {
        Path dir = FabricLoader.getInstance().getConfigDir();
        Path file = dir.resolve("royal-udp-relay.toml");

        RelayConfig cfg = new RelayConfig();
        cfg.path = file;

        if (Files.exists(file)) {
            try {
                cfg.readFrom(file);
            } catch (IOException e) {
                RoyalUDPRelay.LOGGER.warn("[RoyalUDPRelay] Не удалось прочитать конфиг, использую значения по умолчанию: {}", e.toString());
            }
        } else {
            try {
                cfg.writeTo(file);
                RoyalUDPRelay.LOGGER.info("[RoyalUDPRelay] Создан новый конфиг: {}", file);
                RoyalUDPRelay.LOGGER.info("[RoyalUDPRelay] Задайте relay_url и auth_token в config/royal-udp-relay.toml перед использованием.");
            } catch (IOException e) {
                RoyalUDPRelay.LOGGER.error("[RoyalUDPRelay] Не удалось создать конфиг: {}", e.toString());
            }
        }
        return cfg;
    }

    private void readFrom(Path file) throws IOException {
        Map<String, String> raw = new LinkedHashMap<>();
        for (String line : Files.readAllLines(file, StandardCharsets.UTF_8)) {
            String trimmed = line.trim();
            if (trimmed.isEmpty() || trimmed.startsWith("#")) continue;
            int eq = trimmed.indexOf('=');
            if (eq < 0) continue;
            String key = trimmed.substring(0, eq).trim();
            String value = trimmed.substring(eq + 1).trim();
            raw.put(key, unquote(value));
        }

        enabled = parseBool(raw.get("enabled"), enabled);
        serverUuid = raw.getOrDefault("server_uuid", serverUuid);
        if (serverUuid == null || serverUuid.isBlank()) {
            serverUuid = UUID.randomUUID().toString();
        }
        relayUrl = raw.getOrDefault("relay_url", relayUrl);
        authToken = raw.getOrDefault("auth_token", authToken);
        localHost = raw.getOrDefault("local_host", localHost);
        localPort = parseInt(raw.get("local_port"), localPort);
        assignedHost = raw.getOrDefault("assigned_host", assignedHost);
        assignedPort = parseInt(raw.get("assigned_port"), assignedPort);
        stickyAddress = parseBool(raw.get("sticky_address"), stickyAddress);
        reconnect = parseBool(raw.get("reconnect"), reconnect);
        reconnectDelayMs = parseLong(raw.get("reconnect_delay_ms"), reconnectDelayMs);
        maxReconnectDelayMs = parseLong(raw.get("max_reconnect_delay_ms"), maxReconnectDelayMs);
        logLevel = raw.getOrDefault("log_level", logLevel);
        maxUdpPacketSize = parseInt(raw.get("max_udp_packet_size"), maxUdpPacketSize);
        udpSessionIdleTimeoutMs = parseLong(raw.get("udp_session_idle_timeout_ms"), udpSessionIdleTimeoutMs);
    }

    public synchronized void writeTo(Path file) throws IOException {
        StringBuilder sb = new StringBuilder();
        sb.append("# RoyalUDPRelay config\n");
        sb.append("# Строго серверный UDP <-> WSS relay-форвардер (например, для Plasmo Voice).\n\n");

        sb.append("enabled = ").append(enabled).append('\n');
        sb.append("server_uuid = \"").append(serverUuid).append("\"\n\n");

        sb.append("relay_url = \"").append(relayUrl).append("\"\n");
        sb.append("auth_token = \"").append(authToken).append("\"\n\n");

        sb.append("local_host = \"").append(localHost).append("\"\n");
        sb.append("local_port = ").append(localPort).append('\n').append('\n');

        sb.append("assigned_host = \"").append(assignedHost).append("\"\n");
        sb.append("assigned_port = ").append(assignedPort).append('\n').append('\n');

        sb.append("sticky_address = ").append(stickyAddress).append('\n').append('\n');

        sb.append("reconnect = ").append(reconnect).append('\n');
        sb.append("reconnect_delay_ms = ").append(reconnectDelayMs).append('\n');
        sb.append("max_reconnect_delay_ms = ").append(maxReconnectDelayMs).append('\n').append('\n');

        sb.append("log_level = \"").append(logLevel).append("\"\n\n");

        sb.append("max_udp_packet_size = ").append(maxUdpPacketSize).append('\n');
        sb.append("udp_session_idle_timeout_ms = ").append(udpSessionIdleTimeoutMs).append('\n');

        Files.writeString(file, sb.toString(), StandardCharsets.UTF_8);
    }

    /** Сохраняет назначенный relay-ом публичный endpoint (для sticky_address). */
    public synchronized void saveAssignedEndpoint(String host, int port) {
        this.assignedHost = host;
        this.assignedPort = port;
        if (path != null) {
            try {
                writeTo(path);
            } catch (IOException e) {
                RoyalUDPRelay.LOGGER.warn("[RoyalUDPRelay] Не удалось сохранить назначенный endpoint: {}", e.toString());
            }
        }
    }

    private static String unquote(String value) {
        if (value.length() >= 2 && value.startsWith("\"") && value.endsWith("\"")) {
            return value.substring(1, value.length() - 1);
        }
        return value;
    }

    private static boolean parseBool(String v, boolean def) {
        if (v == null) return def;
        return Boolean.parseBoolean(v.trim());
    }

    private static int parseInt(String v, int def) {
        if (v == null || v.isBlank()) return def;
        try {
            return Integer.parseInt(v.trim());
        } catch (NumberFormatException e) {
            return def;
        }
    }

    private static long parseLong(String v, long def) {
        if (v == null || v.isBlank()) return def;
        try {
            return Long.parseLong(v.trim());
        } catch (NumberFormatException e) {
            return def;
        }
    }

    /** Токен для логов — никогда не печатаем его целиком. */
    public String maskedToken() {
        if (authToken == null || authToken.length() <= 4) return "****";
        return authToken.substring(0, 2) + "****" + authToken.substring(authToken.length() - 2);
    }
}
