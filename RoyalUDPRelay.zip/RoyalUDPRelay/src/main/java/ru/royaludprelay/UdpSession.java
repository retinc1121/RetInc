package ru.royaludprelay;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Один UDP-"поток" между конкретным удалённым клиентом relay-сервера (Plasmo Voice
 * игроком) и локальным UDP-сервисом (например, Plasmo Voice сервером на 127.0.0.1:11851).
 *
 * У каждой сессии — свой отдельный локальный DatagramSocket (эпемерный порт), чтобы
 * ответы от локального UDP-сервиса можно было однозначно сопоставить с конкретным
 * clientId на стороне relay и переслать их назад тому же удалённому клиенту.
 *
 * Мод не читает и не изменяет содержимое пакетов — только пересылает datagram как есть.
 */
final class UdpSession {

    final int clientId;
    private final DatagramSocket socket;
    private final InetSocketAddress target;
    private final int maxPacketSize;
    private final Thread receiverThread;
    private volatile boolean running = true;
    final AtomicLong lastActivityMs = new AtomicLong(System.currentTimeMillis());

    UdpSession(int clientId, InetSocketAddress target, int maxPacketSize, DataListener listener) throws IOException {
        this.clientId = clientId;
        this.target = target;
        this.maxPacketSize = maxPacketSize;
        this.socket = new DatagramSocket(0); // любой свободный локальный порт
        this.socket.setSoTimeout(0);

        this.receiverThread = new Thread(() -> receiveLoop(listener), "RoyalUDPRelay-session-" + clientId);
        this.receiverThread.setDaemon(true);
        this.receiverThread.start();
    }

    void sendToLocal(byte[] data) throws IOException {
        if (data.length > maxPacketSize) {
            // Защита от слишком больших пакетов — просто отбрасываем.
            return;
        }
        DatagramPacket packet = new DatagramPacket(data, data.length, target);
        socket.send(packet);
        touch();
    }

    private void receiveLoop(DataListener listener) {
        byte[] buf = new byte[Math.max(maxPacketSize, 2048)];
        while (running) {
            try {
                DatagramPacket packet = new DatagramPacket(buf, buf.length);
                socket.receive(packet);
                touch();
                byte[] data = new byte[packet.getLength()];
                System.arraycopy(packet.getData(), packet.getOffset(), data, 0, packet.getLength());
                listener.onLocalData(clientId, data);
            } catch (IOException e) {
                if (running) {
                    // Сокет мог быть закрыт снаружи (idle timeout / shutdown) — это ожидаемо.
                }
                break;
            }
        }
    }

    void touch() {
        lastActivityMs.set(System.currentTimeMillis());
    }

    boolean isIdle(long idleTimeoutMs) {
        return System.currentTimeMillis() - lastActivityMs.get() > idleTimeoutMs;
    }

    void close() {
        running = false;
        socket.close();
    }

    interface DataListener {
        void onLocalData(int clientId, byte[] data);
    }
}
