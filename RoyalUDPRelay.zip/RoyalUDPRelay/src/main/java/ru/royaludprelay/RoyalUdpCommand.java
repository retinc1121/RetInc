package ru.royaludprelay;

import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.text.Text;

import static net.minecraft.server.command.CommandManager.literal;

/**
 * Только серверные команды. Никакой отправки данных клиенту, никаких
 * custom payload — это обычная Brigadier-команда сервера.
 */
final class RoyalUdpCommand {

    private RoyalUdpCommand() {
    }

    static void register(CommandDispatcher<ServerCommandSource> dispatcher) {
        dispatcher.register(literal("royaludp")
                .requires(src -> src.hasPermissionLevel(3))
                .then(literal("status").executes(RoyalUdpCommand::status))
                .then(literal("reconnect").executes(RoyalUdpCommand::reconnect))
                .then(literal("endpoint").executes(RoyalUdpCommand::endpoint))
        );
    }

    private static int status(com.mojang.brigadier.context.CommandContext<ServerCommandSource> ctx) {
        RoyalUDPRelay mod = RoyalUDPRelay.getInstance();
        ServerCommandSource src = ctx.getSource();

        if (mod == null || mod.getRelayClient() == null) {
            src.sendFeedback(() -> Text.literal("RoyalUDPRelay: мод отключён (enabled = false)."), false);
            return 0;
        }

        RelayConfig cfg = mod.getConfig();
        RelayClient client = mod.getRelayClient();
        boolean connected = client.isConnected();

        src.sendFeedback(() -> Text.literal("RoyalUDPRelay"), false);
        src.sendFeedback(() -> Text.literal("Status: " + (connected ? "CONNECTED" : "DISCONNECTED")), false);
        src.sendFeedback(() -> Text.literal("Local UDP: " + cfg.localHost + ":" + cfg.localPort), false);

        String publicHost = connected ? client.getPublicHost() : cfg.assignedHost;
        int publicPort = connected ? client.getPublicPort() : cfg.assignedPort;
        src.sendFeedback(() -> Text.literal("Public UDP: " + publicHost + ":" + publicPort), false);
        src.sendFeedback(() -> Text.literal("Relay: " + (connected ? "CONNECTED" : "DISCONNECTED")), false);
        src.sendFeedback(() -> Text.literal("Active UDP sessions: " + mod.getUdpForwarder().activeSessions()), false);

        return 1;
    }

    private static int reconnect(com.mojang.brigadier.context.CommandContext<ServerCommandSource> ctx) {
        RoyalUDPRelay mod = RoyalUDPRelay.getInstance();
        ServerCommandSource src = ctx.getSource();

        if (mod == null || mod.getRelayClient() == null) {
            src.sendError(Text.literal("RoyalUDPRelay: мод отключён (enabled = false)."));
            return 0;
        }

        src.sendFeedback(() -> Text.literal("RoyalUDPRelay: переподключение к relay..."), true);
        mod.getRelayClient().forceReconnect();
        return 1;
    }

    private static int endpoint(com.mojang.brigadier.context.CommandContext<ServerCommandSource> ctx) {
        RoyalUDPRelay mod = RoyalUDPRelay.getInstance();
        ServerCommandSource src = ctx.getSource();

        if (mod == null || mod.getRelayClient() == null) {
            src.sendError(Text.literal("RoyalUDPRelay: мод отключён (enabled = false)."));
            return 0;
        }

        RelayClient client = mod.getRelayClient();
        String host = client.isConnected() ? client.getPublicHost() : mod.getConfig().assignedHost;
        int port = client.isConnected() ? client.getPublicPort() : mod.getConfig().assignedPort;

        src.sendFeedback(() -> Text.literal("Public UDP endpoint: " + host + ":" + port), false);
        return 1;
    }
}
