package ru.royaludprelay;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Пересылает UDP-пакеты, полученные от relay, в локальный UDP-сервис (например, Plasmo
 * Voice сервер на 127.0.0.1:11851), и обратно — ответы от локального сервиса на relay.
 *
 * Работает полностью в собственных daemon-потоках, не блокирует Minecraft server tick thread.
 */
public final class UdpForwarder {

    private final RelayConfig config;
    private final InetSocketAddress localTarget;
    private final Map<Integer, UdpSession> sessions = new ConcurrentHashMap<>();
    private final ScheduledExecutorService cleanupExecutor =
            Executors.newSingleThreadScheduledExecutor(r -> {
                Thread t = new Thread(r, "RoyalUDPRelay-udp-cleanup");
                t.setDaemon(true);
                return t;
            });

    private volatile RelayClient relayClient;
    private volatile boolean running = false;

    public UdpForwarder(RelayConfig config) {
        this.config = config;
        this.localTarget = new InetSocketAddress(config.localHost, config.localPort);
    }

    void setRelayClient(RelayClient relayClient) {
        this.relayClient = relayClient;
    }

    public void start() {
        running = true;
        long idleTimeout = config.udpSessionIdleTimeoutMs;
        cleanupExecutor.scheduleAtFixedRate(() -> {
            for (Map.Entry<Integer, UdpSession> entry : sessions.entrySet()) {
                if (entry.getValue().isIdle(idleTimeout)) {
                    sessions.remove(entry.getKey());
                    entry.getValue().close();
                }
            }
        }, idleTimeout, idleTimeout, TimeUnit.MILLISECONDS);
    }

    public void stop() {
        running = false;
        cleanupExecutor.shutdownNow();
        for (UdpSession session : sessions.values()) {
            session.close();
        }
        sessions.clear();
    }

    /** Данные пришли от relay для конкретного удалённого клиента — переслать в локальный UDP-сервис. */
    public void forwardToLocal(int clientId, byte[] data) {
        if (!running) return;
        UdpSession session = sessions.computeIfAbsent(clientId, id -> {
            try {
                return new UdpSession(id, localTarget, config.maxUdpPacketSize, this::onLocalReply);
            } catch (IOException e) {
                RoyalUDPRelay.LOGGER.warn("[RoyalUDPRelay] Не удалось создать UDP-сессию для clientId={}: {}", id, e.toString());
                return null;
            }
        });
        if (session == null) return;
        try {
            session.sendToLocal(data);
        } catch (IOException e) {
            RoyalUDPRelay.LOGGER.debug("[RoyalUDPRelay] Ошибка отправки в локальный UDP-сервис: {}", e.toString());
        }
    }

    private void onLocalReply(int clientId, byte[] data) {
        RelayClient client = this.relayClient;
        if (client != null) {
            client.sendData(clientId, data);
        }
    }

    public int activeSessions() {
        return sessions.size();
    }
}
