package ru.royaludprelay;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.WebSocket;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Клиент защищённого (WSS / TLS) постоянного соединения с Royal UDP Relay Server.
 *
 * Протокол (собственный, не имеет отношения к Minecraft protocol):
 *  - Текстовые (JSON) кадры — управляющие сообщения (auth, auth_ok, auth_fail, ping/pong).
 *  - Бинарные кадры — [4 байта clientId, big-endian][сырые байты UDP datagram].
 *    Мод не декодирует и не изменяет полезную нагрузку — просто перекладывает datagram
 *    между локальным UDP-сервисом и relay.
 */
public final class RelayClient {

    private static final Gson GSON = new Gson();

    private final RelayConfig config;
    private final UdpForwarder udpForwarder;
    private final HttpClient httpClient = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(10))
            .build();

    private final ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor(r -> {
        Thread t = new Thread(r, "RoyalUDPRelay-relay-client");
        t.setDaemon(true);
        return t;
    });

    private final AtomicReference<WebSocket> webSocketRef = new AtomicReference<>();
    private final AtomicBoolean connected = new AtomicBoolean(false);
    private final AtomicBoolean shuttingDown = new AtomicBoolean(false);

    private volatile long currentBackoffMs;
    private volatile String publicHost = "";
    private volatile int publicPort = 0;

    // Буфер для сборки бинарного сообщения, которое может прийти несколькими частями.
    private ByteBuffer binaryAccumulator = null;

    public RelayClient(RelayConfig config, UdpForwarder udpForwarder) {
        this.config = config;
        this.udpForwarder = udpForwarder;
        this.currentBackoffMs = config.reconnectDelayMs;
    }

    public void connect() {
        if (shuttingDown.get()) return;

        URI uri;
        try {
            uri = URI.create(config.relayUrl);
        } catch (IllegalArgumentException e) {
            RoyalUDPRelay.LOGGER.error("[RoyalUDPRelay] Некорректный relay_url: {}", e.toString());
            return;
        }

        WebSocket.Builder builder = httpClient.newWebSocketBuilder()
                .connectTimeout(Duration.ofSeconds(10));

        CompletableFuture<WebSocket> future = builder.buildAsync(uri, new Listener());
        future.whenComplete((ws, error) -> {
            if (error != null) {
                RoyalUDPRelay.LOGGER.warn("[RoyalUDPRelay] Failed to connect to relay: {}", error.toString());
                scheduleReconnect();
            }
        });
    }

    private void scheduleReconnect() {
        if (!config.reconnect || shuttingDown.get()) return;

        long delay = currentBackoffMs;
        currentBackoffMs = Math.min(currentBackoffMs * 2, config.maxReconnectDelayMs);

        RoyalUDPRelay.LOGGER.info("[RoyalUDPRelay] Retrying in {} ms...", delay);
        scheduler.schedule(this::connect, delay, TimeUnit.MILLISECONDS);
    }

    public void forceReconnect() {
        WebSocket ws = webSocketRef.getAndSet(null);
        connected.set(false);
        if (ws != null) {
            try {
                ws.abort();
            } catch (Exception ignored) {
            }
        }
        currentBackoffMs = config.reconnectDelayMs;
        connect();
    }

    public void shutdown() {
        shuttingDown.set(true);
        scheduler.shutdownNow();
        WebSocket ws = webSocketRef.getAndSet(null);
        connected.set(false);
        if (ws != null) {
            try {
                ws.sendClose(WebSocket.NORMAL_CLOSURE, "server stopping").get(2, TimeUnit.SECONDS);
            } catch (Exception e) {
                ws.abort();
            }
        }
    }

    /** Отправить UDP payload, полученный от локального сервиса, обратно конкретному клиенту relay. */
    public void sendData(int clientId, byte[] data) {
        WebSocket ws = webSocketRef.get();
        if (ws == null || !connected.get()) return;

        ByteBuffer buf = ByteBuffer.allocate(4 + data.length);
        buf.putInt(clientId);
        buf.put(data);
        buf.flip();
        ws.sendBinary(buf, true);
    }

    public boolean isConnected() {
        return connected.get();
    }

    public String getPublicHost() {
        return publicHost;
    }

    public int getPublicPort() {
        return publicPort;
    }

    private void sendAuth(WebSocket ws) {
        JsonObject auth = new JsonObject();
        auth.addProperty("type", "auth");
        auth.addProperty("token", config.authToken);
        auth.addProperty("server_uuid", config.serverUuid);
        auth.addProperty("sticky", config.stickyAddress);
        if (config.stickyAddress && config.assignedPort > 0) {
            auth.addProperty("preferred_host", config.assignedHost);
            auth.addProperty("preferred_port", config.assignedPort);
        }
        ws.sendText(GSON.toJson(auth), true);
    }

    private final class Listener implements WebSocket.Listener {

        @Override
        public void onOpen(WebSocket webSocket) {
            RoyalUDPRelay.LOGGER.info("[RoyalUDPRelay] Relay connection established");
            webSocketRef.set(webSocket);
            currentBackoffMs = config.reconnectDelayMs;
            sendAuth(webSocket);
            webSocket.request(1);
        }

        @Override
        public CompletionStage<?> onText(WebSocket webSocket, CharSequence data, boolean last) {
            try {
                JsonObject msg = JsonParser.parseString(data.toString()).getAsJsonObject();
                String type = msg.has("type") ? msg.get("type").getAsString() : "";

                switch (type) {
                    case "auth_ok" -> {
                        connected.set(true);
                        publicHost = msg.has("public_host") ? msg.get("public_host").getAsString() : config.assignedHost;
                        publicPort = msg.has("public_port") ? msg.get("public_port").getAsInt() : config.assignedPort;

                        RoyalUDPRelay.LOGGER.info("[RoyalUDPRelay] UDP forwarding enabled");
                        RoyalUDPRelay.LOGGER.info("[RoyalUDPRelay] Public endpoint assigned:");
                        RoyalUDPRelay.LOGGER.info("[RoyalUDPRelay] {}:{}", publicHost, publicPort);

                        config.saveAssignedEndpoint(publicHost, publicPort);
                    }
                    case "auth_fail" -> {
                        String reason = msg.has("reason") ? msg.get("reason").getAsString() : "unknown";
                        RoyalUDPRelay.LOGGER.error("[RoyalUDPRelay] Relay отклонил подключение: {}", reason);
                        connected.set(false);
                        webSocket.abort();
                    }
                    case "ping" -> {
                        JsonObject pong = new JsonObject();
                        pong.addProperty("type", "pong");
                        webSocket.sendText(GSON.toJson(pong), true);
                    }
                    default -> {
                        // Неизвестный тип управляющего сообщения — игнорируем, но не падаем.
                    }
                }
            } catch (Exception e) {
                RoyalUDPRelay.LOGGER.debug("[RoyalUDPRelay] Некорректное управляющее сообщение от relay: {}", e.toString());
            }

            webSocket.request(1);
            return null;
        }

        @Override
        public CompletionStage<?> onBinary(WebSocket webSocket, ByteBuffer data, boolean last) {
            // Собираем фрагменты, если сообщение пришло несколькими onBinary-вызовами.
            if (binaryAccumulator == null) {
                binaryAccumulator = ByteBuffer.allocate(data.remaining());
                binaryAccumulator.put(data);
            } else {
                ByteBuffer merged = ByteBuffer.allocate(binaryAccumulator.position() + data.remaining());
                binaryAccumulator.flip();
                merged.put(binaryAccumulator);
                merged.put(data);
                binaryAccumulator = merged;
            }

            if (last) {
                binaryAccumulator.flip();
                if (binaryAccumulator.remaining() >= 4) {
                    int clientId = binaryAccumulator.getInt();
                    byte[] payload = new byte[binaryAccumulator.remaining()];
                    binaryAccumulator.get(payload);

                    if (payload.length <= config.maxUdpPacketSize) {
                        udpForwarder.forwardToLocal(clientId, payload);
                    }
                }
                binaryAccumulator = null;
            }

            webSocket.request(1);
            return null;
        }

        @Override
        public void onError(WebSocket webSocket, Throwable error) {
            RoyalUDPRelay.LOGGER.warn("[RoyalUDPRelay] Relay connection error: {}", error.toString());
            connected.set(false);
            webSocketRef.compareAndSet(webSocket, null);
            scheduleReconnect();
        }

        @Override
        public CompletionStage<?> onClose(WebSocket webSocket, int statusCode, String reason) {
            connected.set(false);
            webSocketRef.compareAndSet(webSocket, null);
            if (!shuttingDown.get()) {
                RoyalUDPRelay.LOGGER.warn("[RoyalUDPRelay] Relay connection closed (code={}, reason={})", statusCode, reason);
                scheduleReconnect();
            }
            return null;
        }
    }
}
