# RoyalUDPRelay

Строго серверный Fabric-мод для Minecraft 1.21.11 (Java 21), который пробрасывает
локальный UDP-порт (например, Plasmo Voice) через внешний relay-сервер по WSS,
чтобы игроки могли пользоваться голосовым чатом даже на хостинге без открытого UDP.

## Что было скорректировано в исходном ТЗ

1. **`local_port` и Plasmo Voice.** Мод НЕ открывает свой собственный UDP-сервер
   на `local_host:local_port` — этот порт уже занят самим Plasmo Voice сервером.
   Вместо этого `RoyalUDPRelay` для каждого удалённого игрока (клиента relay)
   создаёт отдельный эпемерный UDP-сокет и **шлёт пакеты на** `local_host:local_port`
   как обычный UDP-клиент, принимая ответы Plasmo обратно на этот же сокет. Так
   реализуется двусторонняя пересылка без конфликта портов и без изменения
   содержимого пакетов. Именно так надо понимать пункт 2 и 4 исходного ТЗ.
2. **Relay-протокол.** В задании описана только сторона мода ("Minecraft-сервер ↔
   RoyalUDPRelay ↔ Relay Server"), но не бинарный протокол между
   RoyalUDPRelay и Relay Server. Я определил простой, безопасный протокол
   поверх WSS (см. раздел "Протокол relay" ниже) — он нужен, чтобы у вас было что
   реализовать на стороне Relay Server. Сам Relay Server в это ТЗ не входил
   (просили только серверный мод), поэтому он не включён в поставку.
3. **`fabric.mod.json`:** нет ни `client` entrypoint, ни `ClientModInitializer`,
   ни client-side networking — только `"environment": "server"` и один server
   entrypoint. Клиенту мод не нужен и не виден.
4. **`gradlew` / `gradlew.bat`.** Бинарный дистрибутив Gradle Wrapper я не
   генерирую руками (это бинарный jar), см. раздел "Сборка" — одна команда его
   создаёт.
5. **Версии тулчейна для 1.21.11** (Loom, Yarn, Fabric Loader, Fabric API) —
   подставлены на момент подготовки, но обязательно сверьте их перед сборкой
   (ссылки в `gradle.properties`), т.к. Fabric обновляет их часто, а 1.21.11 —
   последняя обфусцированная версия Minecraft с необычным циклом релизов.

Суть и все функциональные требования (server-only, UDP-форвардинг, WSS, auth
token, sticky address, reconnect с backoff, команды, логирование без токена)
сохранены без изменений.

## Архитектура

```
Minecraft Server
      |
      | UDP-клиент к 127.0.0.1:11851 (per-player эпемерные сокеты)
      v
Plasmo Voice UDP Server (127.0.0.1:11851)

Minecraft Server (RoyalUDPRelay)
      |
      | WSS (TLS), auth_token, server_uuid
      v
Royal UDP Relay Server  <-- НЕ входит в этот мод, нужно реализовать отдельно
      |
      | публичный UDP
      v
Plasmo Voice Client (игрок)
```

## Протокол relay (WSS)

Текстовые кадры — JSON управляющие сообщения:

```json
// сервер -> relay, сразу после установления соединения
{"type":"auth","token":"...","server_uuid":"...","sticky":true,
 "preferred_host":"voice.example.com","preferred_port":32145}

// relay -> сервер, при успехе
{"type":"auth_ok","public_host":"voice.example.com","public_port":32145}

// relay -> сервер, при отказе
{"type":"auth_fail","reason":"invalid token"}

// в любую сторону, keep-alive
{"type":"ping"} / {"type":"pong"}
```

Бинарные кадры — сырые UDP datagram, с 4-байтовым префиксом `clientId`
(big-endian `int`), который relay использует, чтобы отличать разных публичных
UDP-клиентов (игроков) друг от друга:

```
[4 байта clientId][payload — как есть, без изменений]
```

Мод никогда не декодирует и не изменяет `payload` — это специально сделано
универсальным (не привязано к Plasmo Voice / Opus).

## Проверка выполнена по ТЗ (раздел 19)

- Нет client entrypoint / ClientModInitializer / client networking — мод не
  требуется на клиенте, обычный клиент Minecraft + Plasmo Voice подключается
  как обычно.
- `"environment": "server"` в `fabric.mod.json`.
- Нет custom payload packets и изменений протокола Minecraft.
- UDP форвардинг — отдельные daemon-потоки, не блокирует server tick thread
  (вся сеть — в `UdpSession`, `UdpForwarder`, `RelayClient`, работающих через
  `DatagramSocket` и `java.net.http.WebSocket` в фоне).
- Токен не печатается в логи целиком (см. `RelayConfig#maskedToken`, обычные
  логи вообще не печатают токен).
- Reconnect с exponential backoff (`reconnect_delay_ms` → `max_reconnect_delay_ms`).
- `local_port` мода и TCP RCON на том же номере порта не конфликтуют, т.к.
  мод не биндит `local_port` — он только шлёт туда UDP-пакеты как клиент.

## Сборка

Требуется JDK 21.

```bash
cd RoyalUDPRelay
gradle wrapper --gradle-version 8.10   # один раз — сгенерирует gradlew/gradlew.bat
./gradlew build
```

Перед сборкой откройте `gradle.properties` и сверьте `yarn_mappings`,
`loader_version`, `fabric_version` под 1.21.11 на
<https://fabricmc.net/develop/template/> или через
`https://meta.fabricmc.net/v2/versions/loader/1.21.11`.

Готовый файл появится в `build/libs/RoyalUDPRelay-1.0.0.jar`.

## Установка на сервер

1. Скопируйте `RoyalUDPRelay-1.0.0.jar` в папку `mods/` вашего Fabric-сервера
   (Fabric Loader ≥ 0.18.0, Fabric API для 1.21.11, Java 21).
2. Запустите сервер один раз, чтобы создался `config/royal-udp-relay.toml`.
3. Заполните в конфиге:
   - `relay_url` — адрес вашего Relay Server (`wss://...`);
   - `auth_token` — токен, выданный Relay Server;
   - `local_port` — порт, на котором слушает Plasmo Voice (по умолчанию 11851).
4. Перезапустите сервер. В консоли должно появиться:
   ```
   [RoyalUDPRelay] Starting RoyalUDPRelay...
   [RoyalUDPRelay] Local UDP endpoint: 127.0.0.1:11851
   [RoyalUDPRelay] Connecting to relay...
   [RoyalUDPRelay] Relay connection established
   [RoyalUDPRelay] UDP forwarding enabled
   [RoyalUDPRelay] Public endpoint assigned:
   [RoyalUDPRelay] voice.example.com:32145
   ```
5. В настройках Plasmo Voice для игроков укажите публичный адрес
   `voice.example.com:32145` (или тот, что реально назначил ваш relay).
6. Игроки заходят обычным клиентом Minecraft + Plasmo Voice — устанавливать
   RoyalUDPRelay им не нужно.

Команды (уровень прав 3, только сервер/операторы):

```
/royaludp status
/royaludp reconnect
/royaludp endpoint
```
